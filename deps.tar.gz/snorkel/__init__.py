from .models import SnorkelSession

__version__ = '0.6.2'
