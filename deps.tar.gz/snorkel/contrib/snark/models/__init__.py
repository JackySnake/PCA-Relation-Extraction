class SparkModel(object):
    pass
